function startHandler(input, output, ctx) {
  output.score = 0;
  output.status = "INIT";
}

function incScoreBy10(input, output, ctx) {
  output.score = output.score + 10;
}

function checkMarried(input, output, ctx) {
  if (input.married) {
    return "IncScoreBy50";
  } else {
    return "IncScoreBy100";
  }
}

function incScoreBy50(input, output, ctx) {
  output.score += 50;
}

function incScoreBy100(input, output, ctx) {
  output.score += 100;
}

function end1Handler(input, output, ctx) {
  if (output.score > 250) {
    output.status = "ACCEPTED";
  } else {
    output.status = "REJECTED";
  }
  
  output.salary = input.salary * 10;
}

