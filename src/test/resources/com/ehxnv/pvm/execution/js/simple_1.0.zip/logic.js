function startHandler(input, output) {

}

function p1Handler(input, output) {
   output.name = "Hello, " + input.name;
}

function end1Handler(input, output) {
   // do nothing
}
